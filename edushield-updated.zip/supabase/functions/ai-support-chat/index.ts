import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    if (!OPENAI_API_KEY) {
      throw new Error('OpenAI API key not configured');
    }

    const { message } = await req.json();
    console.log(`AI Support Chat - Processing message: ${message}`);

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: `You are an AI assistant for EduShield, a disaster preparedness education platform for students. 

Your role is to help students with:
- Understanding disaster preparedness procedures
- Answering questions about evacuation drills
- Providing safety tips for different disasters (earthquakes, floods, fires, cyclones)
- Explaining emergency response steps
- Helping with quiz questions about disaster safety
- Providing general support about the platform

Always provide helpful, clear, and safety-focused responses. Be encouraging and educational while keeping safety as the top priority. Use simple language appropriate for students.`
          },
          {
            role: 'user',
            content: message
          }
        ],
        temperature: 0.7,
        max_tokens: 500,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error('OpenAI API error:', errorData);
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    const aiResponse = data.choices[0].message.content;

    return new Response(
      JSON.stringify({ 
        response: aiResponse,
        timestamp: new Date().toISOString()
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error in ai-support-chat function:', error);

    // Offline fallback response (no OpenAI required)
    const fallback = [
      "I'm here to help with disaster preparedness. Here are quick tips:",
      "• Earthquake: Drop, Cover, Hold. Stay away from windows. Evacuate when shaking stops.",
      "• Fire: Stay low, check doors with the back of your hand, never use elevators, meet at assembly point.",
      "• Flood: Move to higher ground, avoid walking/driving through floodwaters, switch off electricity.",
      "• Cyclone: Shelter in an interior room, stay away from glass, wait for official all‑clear.",
      "Need evacuation routes? Open the Routes section and select a disaster type. For alerts, go to Live Disaster Alerts."
    ].join('\n');

    return new Response(
      JSON.stringify({ 
        response: fallback,
        note: 'Served by offline fallback due to AI service issue',
        timestamp: new Date().toISOString()
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});